﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KatalogSamochodowy
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        void logowanie()
        {
            if (login.Text == "admin" && haslo.Password == "admin")
            {
                MessageBox.Show("Pomyślnie zalogowano");
                Obejrzyj_samochod.Visibility = System.Windows.Visibility.Visible;
                login.Background = Brushes.White;
                haslo.Background = Brushes.White;


            }
            else
            {
                MessageBox.Show("Błędne hasło lub login spróbuj ponownie");
                login.Background = Brushes.Red;
                haslo.Background = Brushes.Red;
                login.Text = "";
                haslo.Password = "";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 wyszukiwarka = new Window1();
            wyszukiwarka.Show();
           /* Obejrzyj_samochod.IsEnabled = false;*/
            Window startowe = new Window();

           
            


        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Katalog Samochodowy Wersja 1.4 Wszystkie prawa zastrzeżone");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            logowanie();
        }

        private void Button_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                logowanie();
            }

        }
    }
}
