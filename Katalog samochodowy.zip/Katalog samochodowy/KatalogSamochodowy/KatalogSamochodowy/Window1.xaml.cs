﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace KatalogSamochodowy
{
    /// <summary>
    /// Logika interakcji dla klasy Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)/*wyszukiwanie auta*/
        {
            Window1 wypo = new Window1();
            Window2 samochod = new Window2();

            String marka = auta.SelectedItem.ToString();

            String kolory = kolor.SelectedItem.ToString();
            String lata = rok.SelectedItem.ToString();
            string[] text = System.IO.File.ReadAllLines("C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/dane.txt");
            /*linijki w pliku od 0 po 3 dla kazdego samochodu 0.nazwa rok kolor
                                                              1.adres url zdjecie
                                                              2.opis*/


            switch (marka)
            {
                case "System.Windows.Controls.ComboBoxItem: Audi":
                    {
                        switch (kolory)
                        {
                            case "System.Windows.Controls.ComboBoxItem: Czarny":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                samochod.Opis_Copy.Text = text[0];
                                                samochod.foto.Source = new BitmapImage(new Uri(text[1]));
                                                samochod.Opis.Text = text[2];


                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {

                                                samochod.Opis_Copy.Text = text[3];
                                                samochod.foto.Source = new BitmapImage(new Uri(text[4]));
                                                samochod.Opis.Text = text[5];
                                                break;
                                            }

                                    }
                                }
                                break;
                            case "System.Windows.Controls.ComboBoxItem: Biały":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                samochod.Opis_Copy.Text = text[6];
                                                samochod.foto.Source = new BitmapImage(new Uri(text[7]));
                                                samochod.Opis.Text = text[8];

                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                samochod.Opis_Copy.Text = text[9];
                                                samochod.foto.Source = new BitmapImage(new Uri(text[10]));
                                                samochod.Opis.Text = text[11];

                                                break;
                                            }

                                    }
                                }
                                break;
                        }
                        break;
                    }
                case "System.Windows.Controls.ComboBoxItem: Bmw":
                    {
                        switch (kolory)
                        {
                            case "System.Windows.Controls.ComboBoxItem: Czarny":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                samochod.Opis_Copy.Text = text[12];
                                                samochod.foto.Source = new BitmapImage(new Uri(text[13]));
                                                samochod.Opis.Text = text[14];

                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                samochod.Opis_Copy.Text = text[15];
                                                samochod.foto.Source = new BitmapImage(new Uri(text[16]));
                                                samochod.Opis.Text = text[17];

                                                break;
                                            }

                                    }
                                }
                                break;
                            case "System.Windows.Controls.ComboBoxItem: Biały":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                samochod.Opis_Copy.Text = text[18];
                                                samochod.foto.Source = new BitmapImage(new Uri(text[19]));
                                                samochod.Opis.Text = text[20];

                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                samochod.Opis_Copy.Text = text[21];
                                                samochod.foto.Source = new BitmapImage(new Uri(text[22]));
                                                samochod.Opis.Text = text[23];

                                                break;
                                            }

                                    }
                                }
                                break;
                        }
                        break;
                    }

            }




            samochod.Show();


        }

        private void rok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (auta.SelectedIndex >= 0 && kolor.SelectedIndex >= 0 && rok.SelectedIndex >= 0)
            {
                wyszukaj.IsEnabled = true;
                zapisz.IsEnabled = true;
                zapisz_Copy.IsEnabled = true;
            };

        }
        private void btnOpenFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter= "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.tif;...";
            if (openFileDialog.ShowDialog() == true)
            {
                Uri fileUri = new Uri(openFileDialog.FileName);

                zdjecie.Source = new BitmapImage(fileUri);
                addcar.IsEnabled = true;

            }

        }

        private void Button_Click123(object sender, RoutedEventArgs e)/*dodanie auta*/
        {
           



            string adreszdjecia = zdjecie.Source.ToString().Remove(0, 8);
            string textopisu = opis.Text;



            Window1 wypo = new Window1();



            String marka = auta.SelectedItem.ToString();

            String kolory = kolor.SelectedItem.ToString();
            String lata = rok.SelectedItem.ToString();
            string path = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/dane.txt";
            string[] text = System.IO.File.ReadAllLines(path);
            /*linijki w pliku od 0 po 3 dla kazdego samochodu 0.nazwa rok kolor
                                                              1.adres url zdjecie
                                                              2.opis*/

            switch (marka)
            {
                case "System.Windows.Controls.ComboBoxItem: Audi":
                    {
                        switch (kolory)
                        {
                            case "System.Windows.Controls.ComboBoxItem: Czarny":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                text[0] = "Audi 2022";
                                                text[1] = adreszdjecia;
                                                text[2] = textopisu;
                                                using (StreamWriter sw = File.CreateText(path))
                                                {
                                                    foreach (string line in text) { sw.WriteLine(line); }
                                                }
                                                break;

                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                text[3] = "Audi 2015";
                                                text[4] = adreszdjecia;
                                                text[5] = textopisu;
                                                using (StreamWriter sw = File.CreateText(path))
                                                {
                                                    foreach (string line in text) { sw.WriteLine(line); }
                                                }

                                                break;
                                            }

                                    }
                                }
                                break;
                            case "System.Windows.Controls.ComboBoxItem: Biały":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                text[6] = "Audi 2022";
                                                text[7] = adreszdjecia;
                                                text[8] = textopisu;
                                                using (StreamWriter sw = File.CreateText(path))
                                                {
                                                    foreach (string line in text) { sw.WriteLine(line); }
                                                }

                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                text[9] = "Audi 2015";
                                                text[10] = adreszdjecia;
                                                text[11] = textopisu;
                                                using (StreamWriter sw = File.CreateText(path))
                                                {
                                                    foreach (string line in text) { sw.WriteLine(line); }
                                                }
                                                break;
                                            }

                                    }
                                }
                                break;
                        }
                        break;
                    }
                case "System.Windows.Controls.ComboBoxItem: Bmw":
                    {
                        switch (kolory)
                        {
                            case "System.Windows.Controls.ComboBoxItem: Czarny":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                text[12] = "Bmw 2022";
                                                text[13] = adreszdjecia;
                                                text[14] = textopisu;
                                                using (StreamWriter sw = File.CreateText(path))
                                                {
                                                    foreach (string line in text) { sw.WriteLine(line); }
                                                }
                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                text[15] = "Bmw 2015";
                                                text[16] = adreszdjecia;
                                                text[17] = textopisu;
                                                using (StreamWriter sw = File.CreateText(path))
                                                {
                                                    foreach (string line in text) { sw.WriteLine(line); }
                                                }
                                                break;
                                            }

                                    }
                                }
                                break;
                            case "System.Windows.Controls.ComboBoxItem: Biały":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                text[18] = "Bmw 2022";
                                                text[19] = adreszdjecia;
                                                text[20] = textopisu;
                                                using (StreamWriter sw = File.CreateText(path))
                                                {
                                                    foreach (string line in text) { sw.WriteLine(line); }
                                                }
                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                text[21] = "Bmw 2015";
                                                text[22] = adreszdjecia;
                                                text[23] = textopisu;
                                                using (StreamWriter sw = File.CreateText(path))
                                                {
                                                    foreach (string line in text) { sw.WriteLine(line); }
                                                }
                                                break;
                                            }

                                    }
                                }
                                break;
                        }
                        break;
                    }

            }
            MessageBox.Show("Pomyślnie dodano samochód");
            this.Close();



        }

        private void zapisz_Click(object sender, RoutedEventArgs e)
        {
            kolor.Visibility = Visibility.Hidden;
            rok.Visibility = Visibility.Hidden;
            wyszukaj.Visibility = Visibility.Hidden;
            kolor.Visibility = Visibility.Hidden;
            auta.Visibility = Visibility.Hidden;
            a1.Visibility = Visibility.Hidden;
            a2.Visibility = Visibility.Hidden;
            a3.Visibility = Visibility.Hidden;
            zapisz_Copy.Visibility = Visibility.Hidden;
            /*pokaz inne komponenty*/
            btnOpenFile.Visibility = Visibility.Visible;
            opis.Visibility = Visibility.Visible;
            addcar.Visibility = Visibility.Visible;
            zapisz.Visibility = Visibility.Hidden;
        }

        private void zapisz_Copy_Click(object sender, RoutedEventArgs e)/* usun*/
        {
            String marka = auta.SelectedItem.ToString();

            String kolory = kolor.SelectedItem.ToString();
            String lata = rok.SelectedItem.ToString();
            string path = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/dane.txt";
            string[] text = System.IO.File.ReadAllLines(path);

            /*linijki w pliku od 0 po 3 dla kazdego samochodu 0.nazwa rok kolor
                                                              1.adres url zdjecie
                                                              2.opis*/

            switch (marka)
            {
                case "System.Windows.Controls.ComboBoxItem: Audi":
                    {
                        switch (kolory)
                        {
                            case "System.Windows.Controls.ComboBoxItem: Czarny":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                text[0] = "Brak opisu";
                                                text[1] = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/brakwbazie.jpg";
                                                text[2] = "Brak opisu";
                                                using (StreamWriter sw = File.CreateText(path))
                                                { foreach (string line in text) sw.WriteLine(line); }
                                                break;

                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                text[3] = "Brak opisu";
                                                text[4] = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/brakwbazie.jpg";
                                                text[5] = "Brak opisu";
                                                using (StreamWriter sw = File.CreateText(path))
                                                { foreach (string line in text) sw.WriteLine(line); }
                                                break;
                                            }

                                    }
                                }
                                break;
                            case "System.Windows.Controls.ComboBoxItem: Biały":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                text[6] = "Brak opisu";
                                                text[7] = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/brakwbazie.jpg";
                                                text[8] = "Brak opisu";
                                                using (StreamWriter sw = File.CreateText(path))
                                                { foreach (string line in text) sw.WriteLine(line); }
                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                text[9] = "Brak opisu";
                                                text[10] = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/brakwbazie.jpg";
                                                text[11] = "Brak opisu";
                                                using (StreamWriter sw = File.CreateText(path))
                                                { foreach (string line in text) sw.WriteLine(line); }
                                                break;
                                            }

                                    }
                                }
                                break;
                        }
                        break;
                    }
                case "System.Windows.Controls.ComboBoxItem: Bmw":
                    {
                        switch (kolory)
                        {
                            case "System.Windows.Controls.ComboBoxItem: Czarny":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                text[12] = "Brak opisu";
                                                text[13] = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/brakwbazie.jpg";
                                                text[14] = "Brak opisu";
                                                using (StreamWriter sw = File.CreateText(path))
                                                { foreach (string line in text) sw.WriteLine(line); }
                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                text[15] = "Brak opisu";
                                                text[16] = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/brakwbazie.jpg";
                                                text[17] = "Brak opisu";
                                                using (StreamWriter sw = File.CreateText(path))
                                                { foreach (string line in text) sw.WriteLine(line); }
                                                break;
                                            }

                                    }
                                }
                                break;
                            case "System.Windows.Controls.ComboBoxItem: Biały":
                                {
                                    switch (lata)
                                    {
                                        case "System.Windows.Controls.ComboBoxItem: 2020-2022":
                                            {
                                                text[18] = "Brak opisu";
                                                text[19] = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/brakwbazie.jpg";
                                                text[20] = "Brak opisu";
                                                using (StreamWriter sw = File.CreateText(path))
                                                { foreach (string line in text) sw.WriteLine(line); }
                                                break;
                                            }
                                        case "System.Windows.Controls.ComboBoxItem: 2010-2015":
                                            {
                                                text[21] = "Brak opisu";
                                                text[22] = @"C:/Users/48698/Desktop/Studia sem4/Programowanie/Katalog samochodowy/KatalogSamochodowy/KatalogSamochodowy/brakwbazie.jpg";
                                                text[23] = "Brak opisu";
                                                using (StreamWriter sw = File.CreateText(path))
                                                { foreach (string line in text) sw.WriteLine(line); }
                                                break;
                                            }

                                    }
                                }
                                break;
                        }
                        break;
                    }

            }
            MessageBox.Show("Pomyślnie usunięto samochód");
            this.Close();

        }

    }
}